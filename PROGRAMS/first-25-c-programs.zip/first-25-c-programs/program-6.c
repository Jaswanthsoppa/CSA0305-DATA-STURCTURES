/* 6. Fibonacci using recursion */
#include <stdio.h>
int fib(int n){return n<2?n:fib(n-1)+fib(n-2);} int main(){int n,i;scanf("%d",&n);for(i=0;i<n;i++)printf("%d ",fib(i));}

