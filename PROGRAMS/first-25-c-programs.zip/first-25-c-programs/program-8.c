/* 8. Linear search */
#include <stdio.h>
int main(){int a[100],n,x,i;scanf("%d",&n);for(i=0;i<n;i++)scanf("%d",&a[i]);scanf("%d",&x);for(i=0;i<n&&a[i]!=x;i++);printf(i<n?"Found at %d":"Not found",i);}

