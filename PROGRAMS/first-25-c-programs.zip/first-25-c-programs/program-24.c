/* 24. Prim minimum spanning tree (0 means no edge) */
#include <stdio.h>
#define INF 99999
int main(){int g[20][20],key[20],in[20]={0},n,i,j,u=-1,total=0;scanf("%d",&n);for(i=0;i<n;i++)for(j=0;j<n;j++){scanf("%d",&g[i][j]);if(!g[i][j])g[i][j]=INF;}for(i=0;i<n;i++)key[i]=INF;key[0]=0;for(i=0;i<n;i++){u=-1;for(j=0;j<n;j++)if(!in[j]&&(u<0||key[j]<key[u]))u=j;in[u]=1;total+=key[u];for(j=0;j<n;j++)if(!in[j]&&g[u][j]<key[j])key[j]=g[u][j];}printf("MST cost = %d",total);}

