/* 21. Breadth-first search (vertices 0 to n-1) */
#include <stdio.h>
int main(){int g[20][20],q[20],v[20]={0},n,i,j,f=0,r=0,s;scanf("%d",&n);for(i=0;i<n;i++)for(j=0;j<n;j++)scanf("%d",&g[i][j]);scanf("%d",&s);q[r++]=s;v[s]=1;while(f<r){i=q[f++];printf("%d ",i);for(j=0;j<n;j++)if(g[i][j]&&!v[j])v[j]=1,q[r++]=j;}}

