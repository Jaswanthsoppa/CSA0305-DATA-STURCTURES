/* 25. Kruskal minimum spanning tree */
#include <stdio.h>
struct E{int u,v,w;};int p[20];int find(int x){return p[x]==x?x:(p[x]=find(p[x]));}int main(){struct E e[100],t;int n,m,i,j,cost=0,a,b;scanf("%d%d",&n,&m);for(i=0;i<m;i++)scanf("%d%d%d",&e[i].u,&e[i].v,&e[i].w);for(i=0;i<m-1;i++)for(j=0;j<m-i-1;j++)if(e[j].w>e[j+1].w){t=e[j];e[j]=e[j+1];e[j+1]=t;}for(i=0;i<n;i++)p[i]=i;for(i=0;i<m;i++){a=find(e[i].u);b=find(e[i].v);if(a!=b){p[a]=b;cost+=e[i].w;printf("%d-%d\n",e[i].u,e[i].v);}}printf("MST cost = %d",cost);}
