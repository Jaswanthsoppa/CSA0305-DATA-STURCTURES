/* 22. Depth-first search (vertices 0 to n-1) */
#include <stdio.h>
int g[20][20],v[20],n;void dfs(int x){int j;v[x]=1;printf("%d ",x);for(j=0;j<n;j++)if(g[x][j]&&!v[j])dfs(j);}int main(){int i,j,s;scanf("%d",&n);for(i=0;i<n;i++)for(j=0;j<n;j++)scanf("%d",&g[i][j]);scanf("%d",&s);dfs(s);}

