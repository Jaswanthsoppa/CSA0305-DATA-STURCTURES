/* 17. Merge sort */
#include <stdio.h>
void ms(int a[],int l,int r){int m,i,j,k,b[100];if(l>=r)return;m=(l+r)/2;ms(a,l,m);ms(a,m+1,r);i=l;j=m+1;k=l;while(i<=m&&j<=r)b[k++]=a[i]<a[j]?a[i++]:a[j++];while(i<=m)b[k++]=a[i++];while(j<=r)b[k++]=a[j++];for(i=l;i<=r;i++)a[i]=b[i];}int main(){int a[100],n,i;scanf("%d",&n);for(i=0;i<n;i++)scanf("%d",&a[i]);ms(a,0,n-1);for(i=0;i<n;i++)printf("%d ",a[i]);}

