/* 16. Insertion sort */
#include <stdio.h>
int main(){int a[100],n,i,j,x;scanf("%d",&n);for(i=0;i<n;i++)scanf("%d",&a[i]);for(i=1;i<n;i++){x=a[i];for(j=i-1;j>=0&&a[j]>x;j--)a[j+1]=a[j];a[j+1]=x;}for(i=0;i<n;i++)printf("%d ",a[i]);}

