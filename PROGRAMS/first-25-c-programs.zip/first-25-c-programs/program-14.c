/* 14. Tree traversals */
#include <stdio.h>
#include <stdlib.h>
struct N{int d;struct N*l,*r;};struct N* add(struct N*p,int x){if(!p){p=malloc(sizeof *p);p->d=x;p->l=p->r=NULL;}else if(x<p->d)p->l=add(p->l,x);else p->r=add(p->r,x);return p;}void in(struct N*p){if(p){in(p->l);printf("%d ",p->d);in(p->r);}}void pre(struct N*p){if(p){printf("%d ",p->d);pre(p->l);pre(p->r);}}void post(struct N*p){if(p){post(p->l);post(p->r);printf("%d ",p->d);}}int main(){struct N*r=NULL;int n,x;scanf("%d",&n);while(n--){scanf("%d",&x);r=add(r,x);}in(r);puts("");pre(r);puts("");post(r);}

