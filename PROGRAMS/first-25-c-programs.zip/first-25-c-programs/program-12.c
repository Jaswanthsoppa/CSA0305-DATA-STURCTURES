/* 12. Parentheses balance using stack */
#include <stdio.h>
int main(){char s[100],st[100];int i,t=0;scanf("%99s",s);for(i=0;s[i];i++){if(s[i]=='(')st[t++]=s[i];else if(s[i]==')'&&t)t--;else if(s[i]==')'){puts("Invalid");return 0;}}puts(t?"Invalid":"Valid");}

