/* 10. Linked-list display */
#include <stdio.h>
#include <stdlib.h>
struct Node{int data;struct Node*next;};int main(){int n,i,x;struct Node *head=NULL,*tail=NULL,*p;scanf("%d",&n);while(n--){scanf("%d",&x);p=malloc(sizeof *p);p->data=x;p->next=NULL;if(!head)head=p;else tail->next=p;tail=p;}for(p=head;p;p=p->next)printf("%d ",p->data);}

