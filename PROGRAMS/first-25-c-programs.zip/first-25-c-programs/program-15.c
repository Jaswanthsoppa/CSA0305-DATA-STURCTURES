/* 15. Hashing with linear probing */
#include <stdio.h>
#define M 10
int main(){int h[M],n,x,i,p;for(i=0;i<M;i++)h[i]=-1;scanf("%d",&n);while(n--){scanf("%d",&x);p=x%M;while(h[p]!=-1)p=(p+1)%M;h[p]=x;}for(i=0;i<M;i++)printf("%d: %d\n",i,h[i]);}

