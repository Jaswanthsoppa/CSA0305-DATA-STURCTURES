/* 23. Dijkstra shortest paths (0 means no edge) */
#include <stdio.h>
#define INF 99999
int main(){int g[20][20],d[20],used[20]={0},n,i,j,s,u=-1;scanf("%d",&n);for(i=0;i<n;i++)for(j=0;j<n;j++){scanf("%d",&g[i][j]);if(!g[i][j]&&i!=j)g[i][j]=INF;}scanf("%d",&s);for(i=0;i<n;i++)d[i]=INF;d[s]=0;for(i=0;i<n;i++){u=-1;for(j=0;j<n;j++)if(!used[j]&&(u<0||d[j]<d[u]))u=j;used[u]=1;for(j=0;j<n;j++)if(d[u]+g[u][j]<d[j])d[j]=d[u]+g[u][j];}for(i=0;i<n;i++)printf("%d -> %d = %d\n",s,i,d[i]);}

