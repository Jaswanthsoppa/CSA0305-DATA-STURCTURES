/* 19. Heap sort */
#include <stdio.h>
void heap(int a[],int n,int i){int x=i,l=2*i+1,r=2*i+2,t;if(l<n&&a[l]>a[x])x=l;if(r<n&&a[r]>a[x])x=r;if(x!=i){t=a[i];a[i]=a[x];a[x]=t;heap(a,n,x);}}int main(){int a[100],n,i,t;scanf("%d",&n);for(i=0;i<n;i++)scanf("%d",&a[i]);for(i=n/2-1;i>=0;i--)heap(a,n,i);for(i=n-1;i>0;i--){t=a[0];a[0]=a[i];a[i]=t;heap(a,i,0);}for(i=0;i<n;i++)printf("%d ",a[i]);}

