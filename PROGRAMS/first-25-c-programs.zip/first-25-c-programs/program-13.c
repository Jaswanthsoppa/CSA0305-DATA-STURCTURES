/* 13. Queue: enqueue and dequeue */
#include <stdio.h>
int main(){int q[100],n,i,front=0,rear=-1;scanf("%d",&n);for(i=0;i<n;i++){scanf("%d",&q[++rear]);}front++;for(i=front;i<=rear;i++)printf("%d ",q[i]);}

