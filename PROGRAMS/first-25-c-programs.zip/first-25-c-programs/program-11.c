/* 11. Stack: push, pop, peek */
#include <stdio.h>
int main(){int s[100],top=-1,n,x;scanf("%d",&n);while(n--){scanf("%d",&x);s[++top]=x;}printf("Peek: %d\n",s[top]);while(top>=0)printf("%d ",s[top--]);}

